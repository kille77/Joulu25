
const socket = io();
let qrScanner = null;

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/static/sw.js');
}

function scanCode(){
  document.getElementById("scanModal").style.display="block";
  setTimeout(startScanner,300);
}

function startScanner(){
  qrScanner = new Html5Qrcode("qr-reader");
  Html5Qrcode.getCameras().then(cams=>{
    const cam = cams[cams.length-1];
    qrScanner.start(cam.id,{fps:10,qrbox:250},
      txt=>{
        socket.emit("add_note",{title:txt});
        closeScanModal();
      });
  });
}

function closeScanModal(){
  document.getElementById("scanModal").style.display="none";
  if(qrScanner){qrScanner.stop().catch(()=>{});}
}
