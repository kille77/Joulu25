
self.addEventListener("install",e=>{
 e.waitUntil(caches.open("cache").then(c=>c.addAll(["/"])));
});
